Indian Raga Teaching Pack in English

Files:
1. Book/Complete_Indian_Raga_Teaching_Book_English.txt
   Original English teaching book covering raga basics, thaat, jati, time theory,
   practice method, comparison, glossary, and important ragas.

2. Tables/Important_Ragas_Table.tsv
   Tab-separated table of ragas with thaat/family, time, mood, aroha, avaroha,
   vadi, samvadi, and teaching notes.

3. Question_Answers/Raga_Teaching_QA.txt
   Human-readable question-answer pairs from the same book.

4. Question_Answers/Raga_Teaching_QA_Assistant_Format.jsonl
   Assistant-style JSONL for training or dataset preparation.

Note:
This is an original educational summary, not a copied copyrighted music textbook.
Indian raga traditions vary by gharana, teacher, and performance style. Treat the
tables as a learning foundation, not as the only valid version of each raga.
