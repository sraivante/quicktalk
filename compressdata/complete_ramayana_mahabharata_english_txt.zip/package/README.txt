Complete Ramayana and Mahabharata in English - TXT Bundle

This zip contains public-domain English plain-text editions suitable for reading,
searching, vocabulary practice, or dataset preparation.

RAMAYANA
1. Ramayana_of_Valmiki_English_Verse_Griffith.txt
   - Title: The Ramayan of Valmiki, translated into English verse
   - Translator: Ralph T. H. Griffith
   - Coverage in this edition: Books I to VI
   - Source: Project Gutenberg eBook #24869

MAHABHARATA
1. Mahabharata_Ganguli_Volume_1_Books_1_to_3.txt
   - Books 1 to 3: Adi Parva, Sabha Parva, Vana Parva
   - Source: Project Gutenberg eBook #15474

2. Mahabharata_Ganguli_Volume_2_Books_4_to_7.txt
   - Books 4 to 7: Virata Parva, Udyoga Parva, Bhishma Parva, Drona Parva
   - Source: Project Gutenberg eBook #15475

3. Mahabharata_Ganguli_Volume_3_Books_8_to_12.txt
   - Books 8 to 12: Karna Parva, Salya Parva, Sauptika Parva, Stri Parva, Santi Parva
   - Source: Project Gutenberg eBook #15476

4. Mahabharata_Ganguli_Volume_4_Books_13_to_18.txt
   - Books 13 to 18: Anusasana Parva, Aswamedha Parva, Asramavasika Parva,
     Mausala Parva, Mahaprasthanika Parva, Swargarohanika Parva
   - Source: Project Gutenberg eBook #15477

Mahabharata translator: Kisari Mohan Ganguli.

Note:
Project Gutenberg also lists some individual Mahabharata parva files separately.
Those were not included here because the four-volume Ganguli set already covers
Books 1 through 18 and avoids duplicate text.
