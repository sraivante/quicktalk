10 Big English Vocabulary Novels - TXT Bundle

All files in this zip are plain-text public-domain novels suitable for English reading and vocabulary practice.

Contents:
01. War and Peace - Leo Tolstoy
02. Moby-Dick - Herman Melville
03. Great Expectations - Charles Dickens
04. Jane Eyre - Charlotte Bronte
05. Dracula - Bram Stoker
06. Pride and Prejudice - Jane Austen
07. Frankenstein - Mary Shelley
08. Wuthering Heights - Emily Bronte
09. The Adventures of Sherlock Holmes - Arthur Conan Doyle
10. Alice's Adventures in Wonderland - Lewis Carroll

Source: Project Gutenberg public-domain plain text editions.
